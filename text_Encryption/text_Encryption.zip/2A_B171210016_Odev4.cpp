/****************************************************************************
**					SAKARYA �N�VERS�TES�
**			         B�LG�SAYAR VE B�L���M B�L�MLER� FAK�LTES�
**				    B�LG�SAYAR M�HEND�SL��� B�L�M�
**				          PROGRAMLAMAYA G�R��� DERS�
**
**				�DEV NUMARASI:  4. �DEV
**				��RENC� ADI: KAAN GEC�
**				��RENC� NUMARASI: B171210016
**				DERS GRUBU: A GRUBU

*****************************************************************************/



/****************************************************************************
**			�NEML� NOT	
**			�dev dosyas�nda �rnek ekran ��kt�s� vigenere tablosuna uygun     
**			�ekilde bir ��kt� olu�turmuyor internetten ara�t�rd���mda 
**			ve farkl� anahtar metin kombinasyonlar� denedi�imde 
**			ara�t�rmalar�mda kar��la�t���m sonu�la e� de�er ��kt�
**			bu nedenle �rnek ekran ��kt�s�nda bir yanl��l�k oldu�unu d���n�yorum
**				
**			kaynak:	
**			https://www.dcode.fr/vigenere-cipher
**			https://www.geeksforgeeks.org/vigenere-cipher/	
**			http://user.it.uu.se/~elenaf/Teaching/Krypto2003/vigenere.html
**			
*****************************************************************************/



#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;


int tablo[26][26];					//olu�turaca��m�z vigenere tablosundaki de�erleri tutacak dizi
void VigenereTablosuOlustur();		


class Sifre
{
private:
	char *alfabe;
	char *sifreKelimesi;

public:

	Sifre(char *alfabe, char *sifre)
	{
		sifreKelimesiAta(sifre);

	};

	Sifre()
	{
		this->alfabe = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	};

	char* sifrele(char* sifreMetni)
	{
		VigenereTablosuOlustur();
		char* sifrelenmisMetin = new char;

		for (int i = 0; i < strlen(sifreMetni); i++)
		{
			int x = (int)sifreMetni[i] - 65;		//alfabedeki yerini bulmak i�in 65 ��kar�l�yor 
			int y = (int)sifreKelimesi[i] - 65;
			sifrelenmisMetin[i] = (char)tablo[x][y];//bulunan koordinatlara g�re tablodaki yeri belirleniyor ve metine ekleniyor
		}

		return sifrelenmisMetin;
	};

	char* sifreCoz(char* sifreMetni)
	{
		char* desifreMetin = new char;

		for (int i = 0; i < strlen(sifreMetni); i++)
		{
			string  desifreAlfabe="";
			int sayac = 0;

			for (int j = 0; j < 26; j++)
			{
				if ((int)(sifreKelimesi[i]) + j > 90)					//z harfine geldi�inde ba�a d�nmesi i�in if
				desifreAlfabe += (char)((int)(sifreKelimesi[i])+j-26);	//vigenere tablosundaki �ifreyi ��zecek sat�r olu�turuluyor

				else
					desifreAlfabe += (char)((int)(sifreKelimesi[i]) + j);	
			}

			for (int z = 0; z < desifreAlfabe.length(); z++)
			{
				if (desifreAlfabe[z] == (int)(sifreMetni[i])) {		//kesi�ti�i noktaya kadar ka� karakter oldu�unu say�yor
					break;
					
				}
				else
					sayac++;
			}
			
			int gecici=sayac;

			desifreMetin[i] = (char)(65 + sayac);	//karakter say�s�n� a harfinin numaras�na ekleyerek de�ifre edilen harfi buluyor

		}

		return desifreMetin;
	};

	void sifreKelimesiAta(char* sifre)
	{
		this->sifreKelimesi = sifre;	//�ifre kelimesini at�yor �rnek BSMBSMBSMBS
	};


	~Sifre() {};



};


int main()
{
	setlocale(LC_ALL, "Turkish");
	Sifre sifre;


	string alfabe, sifreKelimesi, metin;



	char harf = 65;
	int harfSecim, i = 0;



	cout << "Kullan�lacak Alfabedeki Harfleri Se�iniz " << endl;

	do {
		do {
			cout << harf << " harfi alfabede olsun mu?  <E:1  H:2> Se�iminiz : ";
			cin >> harfSecim;
			cin.ignore();
	
			if (!(harfSecim == 1 || harfSecim == 2))
			{
				cout << "Yanl�� se�im yapt�n�z tekrar se�iniz."<<endl;
			}
			if (harfSecim == 1)
			{				
				alfabe += harf;
				i++;
			}
	
	
		} while (!(harfSecim == 1 || harfSecim == 2));
	
		harf++;
	} while (harf <= 90);
	system("CLS");



	for (int i = 0; i < alfabe.length(); i++)	//girilen harfleri b�y�k harf yap�yor
	{
	alfabe[i] = toupper(alfabe[i]);
	}
	

	cout << alfabe << "\n Girdi�iniz Alfabedeki Harfleri Kullanarak �ifre Olarak Kullan�lacak Kelimeyi Giriniz : " << endl;
	getline(cin, sifreKelimesi);


	for (int i = 0; i < sifreKelimesi.length(); i++)
	{
		sifreKelimesi[i] = toupper(sifreKelimesi[i]);
	}


	cout << alfabe << "\n Girdi�iniz Alfabedeki Harfleri Kullanarak �ifrelenecek Kelimeyi Giriniz : " << endl;
	getline(cin, metin);


	for (int i = 0; i < metin.length(); i++)
	{
		metin[i] = toupper(metin[i]);
	}
	system("CLS");



	string sifreliMetin = "";

	for (int i = 0, j = 0; i < metin.length(); i++)
	{
		if (metin[i] == 32)			//32 bo�luk karakteri oldu�u i�in bo�luklarda atl�yor
			sifreliMetin += 32;

		else
		{
			if (j < sifreKelimesi.length())
			{
				sifreliMetin += sifreKelimesi[j];
				j++;
			}
			else
			{
				j = 0;
				sifreliMetin += sifreKelimesi[j];
				j++;
			}
		}
	}


	char* sifreliMetinPtr = new char;		//string adrese atan�yor
	int a = 0;
	do {
		*(sifreliMetinPtr + a) = sifreliMetin[a];
		a++;
	} while (sifreliMetin[a] != '\0');


	sifre = Sifre(&alfabe[0], sifreliMetinPtr);	//constructer �al���yor

	

	char* metinPtr = new char;
	a = 0;
	do {										//string adrese atan�yor
		*(metinPtr + a) = metin[a];
		a++;
	} while (metin[a] != '\0');

	char* sifrelimetin = new char;
	sifrelimetin = sifre.sifrele(metinPtr);
	

	cout << "ALFABE \t\t\t\t: " << alfabe << endl;
	cout << "SIFRE \t\t\t\t: " << sifreKelimesi << endl;
	cout << "METIN \t\t\t\t: " << metin << endl;
	cout << "SIFRELENMIS METIN \t\t: " << sifrelimetin << endl;
	cout << "DESIFRE METIN \t\t\t: " << sifre.sifreCoz(sifrelimetin) << endl;




	delete metinPtr;
	delete sifreliMetinPtr;
	delete sifrelimetin;


	system("pause");
	return 0;
}


void VigenereTablosuOlustur()
{
	int z=0;
	for (int i = 0; i < 26; i++, z++)
	{
		for (int j = 0; j < 26; j++)
		{
			int gecici;
			gecici = 65 + (i+j)%26;		//i ye ba�l� olarak birer birer kayarak tabloyu olu�turuyor
			tablo[i][j] = gecici;		//65 a harfinin yeri 26 ise alfabedeki harf say�s�
		}
	}


}

